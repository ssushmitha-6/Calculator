package org.example.calculator;

public enum Operation {

    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE,
    MODULO

}
